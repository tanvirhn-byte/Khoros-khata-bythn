<?php
// খরচের খাতা — PHP backend (SQLite)। কোনো database সেটআপ লাগে না।
const ALLOW_REGISTER = true;   // নিজের অ্যাকাউন্ট খোলার পর false করে দিন
const DELETE_CODE = 'TanvirX';   // অ্যাকাউন্ট মুছতে পাসওয়ার্ডের সাথে এই কোডও লাগবে

date_default_timezone_set('Asia/Dhaka');
ob_start();
ini_set('display_errors', '0');
set_error_handler(function ($no, $str, $file, $line) {
  @file_put_contents(__DIR__ . '/data/error.log', date('c') . ' [php ' . $no . '] ' . str_replace(["\n", "\r"], ' ', $str) . ' @' . basename($file) . ':' . $line . "\n", FILE_APPEND | LOCK_EX);
  return true;
});
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
function out($d, $c = 200) { while (ob_get_level()) ob_end_clean(); http_response_code($c); echo json_encode($d, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE); exit; }

if (!extension_loaded('pdo_sqlite')) out(['error' => 'এই hosting-এ PDO SQLite চালু নেই। hosting support-কে চালু করতে বলুন।'], 500);

try {
  $dir = __DIR__ . '/data';
  if (!is_dir($dir)) mkdir($dir, 0750, true);
  $db = new PDO('sqlite:' . $dir . '/khoroch.sqlite');
  $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $db->exec('PRAGMA busy_timeout=8000;');
  try { $db->exec('PRAGMA journal_mode=WAL;'); } catch (Throwable $e) {}
  if ((int)$db->query('PRAGMA user_version')->fetchColumn() < 6) {
  $db->exec("
  CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, hash TEXT NOT NULL, rev INTEGER NOT NULL DEFAULT 0);
  CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
  CREATE TABLE IF NOT EXISTS logs(id INTEGER PRIMARY KEY, t INTEGER, type TEXT, who TEXT, ip TEXT);
  CREATE INDEX IF NOT EXISTS ix_logs ON logs(type,ip,t);
  CREATE TABLE IF NOT EXISTS visits(day TEXT, vid TEXT, hits INTEGER, last INTEGER, plat TEXT, PRIMARY KEY(day,vid));
  CREATE TABLE IF NOT EXISTS tokens(token_hash TEXT PRIMARY KEY, user_id INTEGER, created INTEGER);
  CREATE TABLE IF NOT EXISTS groups_(user_id INTEGER, id TEXT, name TEXT, updated INTEGER, deleted INTEGER DEFAULT 0, rev INTEGER, PRIMARY KEY(user_id,id));
  CREATE TABLE IF NOT EXISTS categories(user_id INTEGER, id TEXT, group_id TEXT, parent TEXT, name TEXT, updated INTEGER, deleted INTEGER DEFAULT 0, rev INTEGER, PRIMARY KEY(user_id,id));
  CREATE TABLE IF NOT EXISTS expenses(user_id INTEGER, id TEXT, group_id TEXT, amount REAL, date TEXT, time TEXT, descr TEXT, note TEXT, updated INTEGER, deleted INTEGER DEFAULT 0, rev INTEGER, PRIMARY KEY(user_id,id));
  CREATE TABLE IF NOT EXISTS expense_categories(user_id INTEGER, expense_id TEXT, category_id TEXT, PRIMARY KEY(user_id,expense_id,category_id));
  CREATE INDEX IF NOT EXISTS ix_exp ON expenses(user_id,group_id,date);
  CREATE TABLE IF NOT EXISTS prefs(user_id INTEGER, id TEXT, v TEXT, updated INTEGER, deleted INTEGER DEFAULT 0, rev INTEGER, PRIMARY KEY(user_id,id));
  ");

  $cols = array_column($db->query('PRAGMA table_info(users)')->fetchAll(PDO::FETCH_ASSOC), 'name');
  if (!in_array('created', $cols)) $db->exec('ALTER TABLE users ADD COLUMN created INTEGER');
  if (!in_array('synced', $cols)) $db->exec('ALTER TABLE users ADD COLUMN synced INTEGER');
  if (!in_array('status', $cols)) $db->exec("ALTER TABLE users ADD COLUMN status TEXT NOT NULL DEFAULT 'active'");
  $db->exec('PRAGMA user_version=6');
  }

  function q($sql, $p = []) { global $db; $s = $db->prepare($sql); $s->execute($p); return $s; }
  function logev($type, $who = '') {
    try {   // লগ লিখতে না পারলেও লগইন/সিঙ্ক যেন না থামে
      q('INSERT INTO logs(t,type,who,ip) VALUES(?,?,?,?)', [time(), $type, $who, $_SERVER['REMOTE_ADDR'] ?? '']);
      if (mt_rand(1, 20) === 1) q('DELETE FROM logs WHERE id < (SELECT MAX(id) FROM logs) - 500');
    } catch (Throwable $exl) {}
  }
  function newToken($uid) { $t = bin2hex(random_bytes(32)); q('INSERT INTO tokens VALUES(?,?,?)', [hash('sha256', $t), $uid, time()]); return $t; }

  $raw = (string)file_get_contents('php://input', false, null, 0, 2500001);
  if (strlen($raw) > 2500000) out(['error' => 'অনুরোধটি অনেক বড়'], 413);
  $in = json_decode($raw, true) ?: [];
  $a = $_GET['a'] ?? '';

  if ($a === 'health') out(['ok' => true]);

  if ($a === 'register') {
    $rm = q("SELECT v FROM settings WHERE k='reg_mode'")->fetchColumn();
    if ($rm === false) {
      $ar = q("SELECT v FROM settings WHERE k='allow_register'")->fetchColumn();
      $rm = $ar === false ? (ALLOW_REGISTER ? 'open' : 'closed') : ($ar === '1' ? 'open' : 'closed');
    }
    if ($rm === 'closed') out(['error' => 'নতুন অ্যাকাউন্ট খোলা বন্ধ আছে'], 403);
    $rip = $_SERVER['REMOTE_ADDR'] ?? '';
    if ((int)q("SELECT COUNT(*) FROM logs WHERE type='register' AND ip=? AND t>?", [$rip, time() - 3600])->fetchColumn() >= 5)
      out(['error' => 'একই জায়গা থেকে অনেক অ্যাকাউন্ট খোলা হয়েছে। ১ ঘণ্টা পর আবার চেষ্টা করুন।'], 429);
    $email = strtolower(trim($in['email'] ?? '')); $pw = (string)($in['password'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pw) < 8) out(['error' => 'সঠিক ইমেইল এবং ৮+ অক্ষরের পাসওয়ার্ড দিন'], 400);
    if (q('SELECT 1 FROM users WHERE email=?', [$email])->fetch()) out(['error' => 'এই ইমেইল আগে থেকেই আছে'], 409);
    q('INSERT INTO users(email,hash,created,status) VALUES(?,?,?,?)', [$email, password_hash($pw, PASSWORD_DEFAULT), time(), $rm === 'approval' ? 'pending' : 'active']);
    logev('register', $email);
    if ($rm === 'approval') out(['error' => 'অ্যাকাউন্ট তৈরি হয়েছে। অ্যাডমিনের অনুমোদনের পর লগইন করতে পারবেন।'], 403);
    out(['token' => newToken((int)$db->lastInsertId())]);
  }

  if ($a === 'login') {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    if ((int)q("SELECT COUNT(*) FROM logs WHERE type='login_fail' AND ip=? AND t>?", [$ip, time() - 900])->fetchColumn() >= 5)
      out(['error' => 'অনেকবার ভুল হয়েছে। ১৫ মিনিট পর আবার চেষ্টা করুন।'], 429);
    $em = strtolower(trim($in['email'] ?? ''));
    $u = q('SELECT * FROM users WHERE email=?', [$em])->fetch(PDO::FETCH_ASSOC);
    if (!$u || !password_verify((string)($in['password'] ?? ''), $u['hash'])) { logev('login_fail', $em); usleep(400000); out(['error' => 'ইমেইল বা পাসওয়ার্ড ভুল'], 401); }
    if (($u['status'] ?? 'active') === 'pending') out(['error' => 'অ্যাডমিনের অনুমোদনের অপেক্ষায় আছে।'], 403);
    if (($u['status'] ?? 'active') === 'blocked') out(['error' => 'এই অ্যাকাউন্ট বন্ধ করা আছে।'], 403);
    logev('login', $em);
    out(['token' => newToken((int)$u['id'])]);
  }

  // --- এখান থেকে লগইন লাগে ---
  if ($a === 'config') {
    $vid = (string)($in['vid'] ?? '');
    if (preg_match('/^[a-z0-9]{8,32}$/', $vid)) {
      $day = date('Y-m-d'); $now = time(); $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
      $plat = stripos($ua, 'android') !== false ? 'Android' : (preg_match('/iphone|ipad|ipod/i', $ua) ? 'iOS' : 'Desktop');
      try {   // ভিজিট গোনা: ১০ মিনিটে একবার; ব্যর্থ হলেও অ্যাপ চলবে
        $lv = q('SELECT last FROM visits WHERE day=? AND vid=?', [$day, $vid])->fetchColumn();
        if ($lv === false) q('INSERT OR IGNORE INTO visits(day,vid,hits,last,plat) VALUES(?,?,1,?,?)', [$day, $vid, $now, $plat]);
        elseif ($now - (int)$lv >= 600) q('UPDATE visits SET hits=hits+1,last=? WHERE day=? AND vid=?', [$now, $day, $vid]);
        if (mt_rand(1, 200) === 1) q('DELETE FROM visits WHERE day<?', [date('Y-m-d', time() - 400 * 86400)]);
      } catch (Throwable $exv) {}
    }
    $get = function ($k, $d) { $v = q('SELECT v FROM settings WHERE k=?', [$k])->fetchColumn(); $j = $v !== false ? json_decode($v, true) : null; return $j === null ? $d : $j; };
    $now = date('Y-m-d\TH:i');
    $notices = [];
    foreach ((array)$get('notices', []) as $n) {
      $from = (string)($n['from'] ?? ''); $to = (string)($n['to'] ?? '');
      if (strlen($from) === 10) $from .= 'T00:00';
      if (strlen($to) === 10) $to .= 'T23:59';
      if (empty($n['on']) || ($from !== '' && $from > $now) || ($to !== '' && $to < $now)) continue;
      $notices[] = ['id' => (string)($n['id'] ?? ''), 'title' => (string)($n['title'] ?? ''), 'msg' => (string)($n['msg'] ?? ''), 'link' => (string)($n['link'] ?? ''), 'btn' => (string)($n['btn'] ?? ''),
        'type' => (string)($n['type'] ?? 'info'), 'loc' => array_values((array)($n['loc'] ?? [])), 'freq' => (string)($n['freq'] ?? 'always'), 'every' => (int)($n['every'] ?? 24), 'everyS' => (int)($n['everyS'] ?? 0), 'socs' => array_values((array)($n['socs'] ?? [])),
        'secs' => (int)($n['secs'] ?? 0), 'aud' => (string)($n['aud'] ?? 'all'), 'pri' => (int)($n['pri'] ?? 10), 'soc' => !empty($n['soc']) ? 1 : 0];
    }
    usort($notices, function ($x, $y) { return $x['pri'] <=> $y['pri']; });
    $sraw = (array)$get('social', []);
    if ($sraw && array_keys($sraw) !== range(0, count($sraw) - 1)) {   // পুরনো ফরম্যাট
      $tmp = []; foreach ($sraw as $k => $x) $tmp[] = ['p' => $k, 'label' => '', 'url' => $x['url'] ?? '', 'on' => $x['on'] ?? 0, 'loc' => $x['loc'] ?? []];
      $sraw = $tmp;
    }
    $social = [];
    foreach ($sraw as $x) if (!empty($x['on']) && !empty($x['url'])) $social[] = ['id' => (string)($x['id'] ?? ('k' . substr(md5(($x['p'] ?? '') . '|' . ($x['url'] ?? '')), 0, 6))), 'k' => (string)($x['p'] ?? ''), 'label' => (string)($x['label'] ?? ''), 'url' => (string)$x['url'], 'loc' => array_values((array)($x['loc'] ?? []))];
    $sm = q("SELECT v FROM settings WHERE k='socmode'")->fetchColumn();
    $pl = (int)q("SELECT v FROM settings WHERE k='poll'")->fetchColumn(); if ($pl < 5 || $pl > 120) $pl = 15;
    out(['poll' => $pl, 'notices' => $notices, 'social' => $social, 'socmode' => $sm === false ? 'none' : $sm, 'welcome' => (object)$get('welcome', []), 'brand' => (object)$get('brand', []), 'maint' => $get('maint', ['on' => 0, 'msg' => ''])]);
  }

  $tok = (string)($in['token'] ?? ($_GET['token'] ?? ''));
  $row = q('SELECT user_id FROM tokens WHERE token_hash=?', [hash('sha256', $tok)])->fetch(PDO::FETCH_ASSOC);
  if (!$row) out(['error' => 'লগইন করুন'], 401);
  $u = (int)$row['user_id'];
  $stt = q('SELECT status FROM users WHERE id=?', [$u])->fetchColumn();
  if ($stt !== false && $stt !== 'active') out(['error' => 'অ্যাকাউন্ট বন্ধ আছে'], 401);

  if ($a === 'ping') {   // খুব হালকা: শুধু জানায় সার্ভারে নতুন পরিবর্তন আছে কি না
    out(['rev' => (int)q('SELECT rev FROM users WHERE id=?', [$u])->fetchColumn(), 'now' => (int)(microtime(true) * 1000)]);
  }

  if ($a === 'passwd') {
    $r = q('SELECT hash FROM users WHERE id=?', [$u])->fetch(PDO::FETCH_ASSOC);
    $new = (string)($in['new'] ?? '');
    if (!$r || !password_verify((string)($in['old'] ?? ''), $r['hash'])) { usleep(400000); out(['error' => 'বর্তমান পাসওয়ার্ড ভুল'], 403); }
    if (strlen($new) < 8) out(['error' => 'নতুন পাসওয়ার্ড ৮+ অক্ষরের হতে হবে'], 400);
    q('UPDATE users SET hash=? WHERE id=?', [password_hash($new, PASSWORD_DEFAULT), $u]);
    logev('passwd', 'user#' . $u);
    q('DELETE FROM tokens WHERE user_id=? AND token_hash<>?', [$u, hash('sha256', $tok)]);
    out(['ok' => true]);
  }

  if ($a === 'delacct') {
    $r = q('SELECT hash FROM users WHERE id=?', [$u])->fetch(PDO::FETCH_ASSOC);
    if (!$r || !password_verify((string)($in['pw'] ?? ''), $r['hash'])) { usleep(400000); out(['error' => 'পাসওয়ার্ড ভুল'], 403); }
    $dc = q("SELECT v FROM settings WHERE k='delete_code'")->fetchColumn();
    if ($dc === false) $dc = DELETE_CODE;
    if (!hash_equals((string)$dc, (string)($in['code'] ?? ''))) { usleep(400000); out(['error' => 'ইউনিভার্সাল কোড ভুল'], 403); }
    logev('delacct', 'user#' . $u);
    $db->beginTransaction();
    foreach (['expense_categories', 'expenses', 'categories', 'groups_', 'prefs', 'tokens'] as $t) q("DELETE FROM $t WHERE user_id=?", [$u]);
    q('DELETE FROM users WHERE id=?', [$u]);
    $db->commit();
    out(['ok' => true]);
  }

  if ($a === 'sync') {
    $nowMs = (int)(microtime(true) * 1000);
    $since = max(0, (int)($in['since'] ?? 0));
    $P = (array)($in['parents'] ?? []); $C = (array)($in['cats'] ?? []); $E = (array)($in['exps'] ?? []); $R = (array)($in['prefs'] ?? []);
    if (count($P) + count($C) + count($E) + count($R) > 400) out(['error' => 'একবারে অনেক বেশি পরিবর্তন পাঠানো হয়েছে'], 413);
    $okId = function ($v) { return is_string($v) && preg_match('/^[A-Za-z0-9_-]{1,40}$/', $v); };
    $sv = function ($v, $n) { $v = (string)$v; return function_exists('mb_substr') ? mb_substr($v, 0, $n) : substr($v, 0, $n); };
    $clamp = function ($v) use ($nowMs) { return min((int)$v, $nowMs + 300000); };   // ভুল ঘড়ির ভবিষ্যৎ সময় আটকানো
    $pushed = ['groups_' => [], 'categories' => [], 'expenses' => [], 'prefs' => []];
    if ($P || $C || $E || $R) {
      $tries = 0;
      while (true) {
        $pushed = ['groups_' => [], 'categories' => [], 'expenses' => [], 'prefs' => []];
        try {
          $db->beginTransaction();
          q('UPDATE users SET rev=rev WHERE id=?', [$u]);   // লেখার তালা এখনই নেওয়া — দুই ফোন একসাথে পাঠালেও rev গুলিয়ে যাবে না
          $rev = (int)q('SELECT rev FROM users WHERE id=?', [$u])->fetchColumn();
          $newer = function ($t, $id, $upd) use ($u) {   // last-write-wins: যার updated বেশি সে জেতে
            $o = q("SELECT updated FROM $t WHERE user_id=? AND id=?", [$u, $id])->fetchColumn();
            return $o === false || $upd > (int)$o;
          };
          foreach ($P as $p) if (is_array($p) && $okId($p['id'] ?? null)) {
            $pushed['groups_'][] = $p['id']; $upd = $clamp($p['updated'] ?? 0);
            if ($newer('groups_', $p['id'], $upd)) q('INSERT OR REPLACE INTO groups_ VALUES(?,?,?,?,?,?)', [$u, $p['id'], $sv($p['name'] ?? '', 100), $upd, empty($p['deleted']) ? 0 : 1, ++$rev]);
          }
          foreach ($C as $c) if (is_array($c) && $okId($c['id'] ?? null)) {
            $pushed['categories'][] = $c['id']; $upd = $clamp($c['updated'] ?? 0);
            if ($newer('categories', $c['id'], $upd)) q('INSERT OR REPLACE INTO categories VALUES(?,?,?,?,?,?,?,?)', [$u, $c['id'], $okId($c['pid'] ?? null) ? $c['pid'] : '', $okId($c['parent'] ?? null) ? $c['parent'] : null, $sv($c['name'] ?? '', 100), $upd, empty($c['deleted']) ? 0 : 1, ++$rev]);
          }
          foreach ($E as $e) if (is_array($e) && $okId($e['id'] ?? null)) {
            $pushed['expenses'][] = $e['id']; $upd = $clamp($e['updated'] ?? 0);
            if ($newer('expenses', $e['id'], $upd)) {
              $amt = (float)($e['amt'] ?? 0); if (!is_finite($amt)) $amt = 0; $amt = max(0, min(1e12, $amt));
              q('INSERT OR REPLACE INTO expenses VALUES(?,?,?,?,?,?,?,?,?,?,?)', [$u, $e['id'], $okId($e['pid'] ?? null) ? $e['pid'] : '', $amt, $sv($e['dt'] ?? '', 10), $sv($e['tm'] ?? '', 5), $sv($e['desc'] ?? '', 300), $sv($e['note'] ?? '', 1000), $upd, empty($e['deleted']) ? 0 : 1, ++$rev]);
              q('DELETE FROM expense_categories WHERE user_id=? AND expense_id=?', [$u, $e['id']]);
              foreach (array_slice(array_unique((array)($e['cats'] ?? [])), 0, 40) as $cid) if ($okId($cid)) q('INSERT OR IGNORE INTO expense_categories VALUES(?,?,?)', [$u, $e['id'], $cid]);
            }
          }
          // সেটিংস (ডিফল্ট গ্রুপ, নাম, মুদ্রার চিহ্ন, মাসিক বাজেট) — অ্যাকাউন্টের সাথে সব ডিভাইসে মিলে যায়
          foreach ($R as $r) if (is_array($r) && is_string($r['id'] ?? null) && preg_match('/^(defg|name|sym|budget:[A-Za-z0-9_-]{1,40})$/', $r['id'])) {
            $pushed['prefs'][] = $r['id']; $upd = $clamp($r['updated'] ?? 0);
            if ($newer('prefs', $r['id'], $upd)) q('INSERT OR REPLACE INTO prefs VALUES(?,?,?,?,?,?)', [$u, $r['id'], $sv($r['v'] ?? '', 100), $upd, empty($r['deleted']) ? 0 : 1, ++$rev]);
          }
          q('UPDATE users SET rev=?, synced=? WHERE id=?', [$rev, time(), $u]);
          $db->commit();
          break;
        } catch (Throwable $ex) {
          try { if ($db->inTransaction()) $db->rollBack(); } catch (Throwable $ex2) {}
          $m = strtolower($ex->getMessage());
          if (++$tries >= 4 || (strpos($m, 'lock') === false && strpos($m, 'busy') === false)) throw $ex;
          usleep(250000 * $tries);
        }
      }
    }
    $rev = (int)q('SELECT rev FROM users WHERE id=?', [$u])->fetchColumn();
    $notice = q("SELECT v FROM settings WHERE k='notice'")->fetchColumn();
    if ($notice === false) $notice = '';
    // নতুন পরিবর্তন + এইমাত্র পাঠানো আইটেমের চূড়ান্ত (সার্ভারের) অবস্থা — যাতে কোনো ডিভাইস পিছিয়ে না থাকে
    $sel = function ($t) use ($u, $since, $pushed) {
      $ids = array_values(array_unique($pushed[$t]));
      $sql = "SELECT * FROM $t WHERE user_id=? AND (rev>?" . ($ids ? ' OR id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')' : '') . ')';
      return q($sql, array_merge([$u, $since], $ids))->fetchAll(PDO::FETCH_ASSOC);
    };
    $lk = $db->prepare('SELECT category_id FROM expense_categories WHERE user_id=? AND expense_id=?');
    out([
      'since' => $rev, 'now' => $nowMs, 'notice' => $notice,
      'parents' => array_map(fn($p) => ['id' => $p['id'], 'name' => $p['name'], 'updated' => (int)$p['updated'], 'deleted' => (int)$p['deleted']], $sel('groups_')),
      'cats' => array_map(fn($c) => ['id' => $c['id'], 'pid' => $c['group_id'], 'parent' => $c['parent'], 'name' => $c['name'], 'updated' => (int)$c['updated'], 'deleted' => (int)$c['deleted']], $sel('categories')),
      'prefs' => array_map(fn($x) => ['id' => $x['id'], 'v' => $x['v'], 'updated' => (int)$x['updated'], 'deleted' => (int)$x['deleted']], $sel('prefs')),
      'exps' => array_map(function ($e) use ($lk, $u) {
        $lk->execute([$u, $e['id']]);
        return ['id' => $e['id'], 'pid' => $e['group_id'], 'amt' => (float)$e['amount'], 'dt' => $e['date'], 'tm' => $e['time'],
          'desc' => $e['descr'], 'note' => $e['note'], 'updated' => (int)$e['updated'], 'deleted' => (int)$e['deleted'], 'cats' => $lk->fetchAll(PDO::FETCH_COLUMN)];
      }, $sel('expenses')),
    ]);
  }

  // Report: overall total একবারই গোনা হয়; category total-এ sub-category ধরা হয়, কিন্তু একই খরচ দুবার নয়।
  if ($a === 'report') {
    $g = $_GET['group'] ?? ''; $from = $_GET['from'] ?? '0000-01-01'; $to = $_GET['to'] ?? '9999-12-31';
    $base = 'user_id=? AND group_id=? AND deleted=0 AND date>=? AND date<=?';
    $t = q("SELECT COALESCE(SUM(amount),0) total, COUNT(*) n FROM expenses WHERE $base", [$u, $g, $from, $to])->fetch(PDO::FETCH_ASSOC);
    $cats = [];
    foreach (q('SELECT id,name FROM categories WHERE user_id=? AND group_id=? AND parent IS NULL AND deleted=0', [$u, $g])->fetchAll(PDO::FETCH_ASSOC) as $c) {
      $r = q("WITH RECURSIVE d(id) AS (
          SELECT id FROM categories WHERE user_id=? AND id=? AND deleted=0
          UNION ALL SELECT c.id FROM categories c JOIN d ON c.parent=d.id WHERE c.user_id=? AND c.deleted=0)
        SELECT COALESCE(SUM(amount),0) total, COUNT(*) n FROM expenses e WHERE $base
          AND EXISTS(SELECT 1 FROM expense_categories x WHERE x.user_id=e.user_id AND x.expense_id=e.id AND x.category_id IN (SELECT id FROM d))",
        [$u, $c['id'], $u, $u, $g, $from, $to])->fetch(PDO::FETCH_ASSOC);
      $cats[] = ['id' => $c['id'], 'name' => $c['name'], 'total' => (float)$r['total'], 'n' => (int)$r['n']];
    }
    out(['total' => (float)$t['total'], 'transactions' => (int)$t['n'], 'categories' => $cats]);
  }

  out(['error' => 'অজানা অনুরোধ'], 404);
} catch (Throwable $e) {
  try { if (isset($db) && $db->inTransaction()) $db->rollBack(); } catch (Throwable $e2) {}
  $lf = __DIR__ . '/data/error.log';
  @file_put_contents($lf, date('c') . ' [' . ($a ?? '') . '] ' . str_replace(["\n", "\r"], ' ', $e->getMessage()) . ' @' . basename($e->getFile()) . ':' . $e->getLine() . "\n", FILE_APPEND | LOCK_EX);
  if (@filesize($lf) > 200000) @file_put_contents($lf, '');
  out(['error' => 'সার্ভারে সমস্যা হয়েছে'], 500);
}
